//app.js
App({
  onLaunch: async function () {
    // 展示本地存储能力
    var logs = wx.getStorageSync('logs') || [];
    logs.unshift(Date.now());
    wx.setStorageSync('logs', logs);

    //云开发环境的初始化
    wx.cloud.init({
      env: "abc-7g742zsa5e0d63a6",
      traceUser: true
    })
  },

  globalData: {
    userInfo: null,
    yunPath: "cloud://abc-7g742zsa5e0d63a6.6162-abc-7g742zsa5e0d63a6-1303875094/",
    currentUseId: '',
    count: 0,
    countId: ''
  },
})