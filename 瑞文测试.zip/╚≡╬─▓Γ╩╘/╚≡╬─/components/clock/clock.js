Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
    timer: '',//定时器名字
    countDownNum: '40:00'//倒计时初始值
  },

  lifetimes: {
    attached: function () {
      this.countDown();
      // this.updateTime();
    }
  },

  /**
   * 组件的方法列表
   */
  methods: {
    countDown: function () {
      var that = this;
      var countDownNum = that.data.countDownNum;
      console.log(countDownNum)
      var dateList = countDownNum.split(":");
      var m, s;
      var time = parseInt((parseInt(dateList[0]) * 60) + parseInt(dateList[1]));
          var timer = setInterval(() => {
            if (time > 0) {
              --time;
              m = Math.floor(time / 60 % 60);
              s = Math.floor(time % 60);
              s = s < 10 ? "0" + s : s
              m = m < 10 ? "0" + m : m
              this.setData({
                countDownNum: m + ":" + s
              });
            } else {
              console.log('已截止');
                wx.showToast({
                  title: '时间已截止',
                })
              clearInterval(timer);
              that.setData({
                countDownNum: '00:00'
              })
            }
          }, 1000);
      
      },
        
        // m = Math.floor(time / 60 % 60);  我是因为看到网上说set
        // s = Math.floor(time % 60);
        // s = s < 10 ? "0" + s : s
        // m = m < 10 ? "0" + m : m
      //   that.setData({
      //     countDownNum: m + "：" + s,
      //   })
      //   console.log(countDownNum);
      //   //递归每秒调用countTime方法，显示动态时间效果,这个是什么？？setTimeout这一句吗嗯嗯  countDown就是我们现在在写的这个函数  
      //   //setTimeout的作用就是 第一个参数是一个函数，第二个参数是延迟执行的时间  这个可以不断刷新时间
      //   // setTimeout(that.countDown, 1000);
      // } else {
      //   console.log('已截止');
      //   clearInterval(that.data.timer);
      //   that.setData({
      //     countDownNum: '00:00'
      //   })
      // }
    // },
    updateTime: function(){
      setInterval(() => {
        this.countDown();
      }, 1000);
    }
  }
})
