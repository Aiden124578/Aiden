const app = getApp();
// 加载数据库
const db = wx.cloud.database();
const util = require('../../utils/util');
Component({

  /**
   * 组件的初始数据
   */
  data: {
    timer: '', //定时器名字
    countDownNum: '40:00', //倒计时初始值
    min: 0,   //答题时间
    src: "",   //题目路径
    flag: 0,   //判断答题是否结束
    count: 0,   //答对题目数量
    value: 0,  //选中选项
    number: 1,   //题号
    percent: 1,  //进度
    url: '#',
    random: [],   //打乱的数组
    result: [],  //返回数据的结果
    counts: [0, 0, 0, 0, 0, 0, 0],   //分别计算ABCDF五类题目答对的数量
    radioname: ["A.", "B.", "C.", "D.", "E.", "F."],
    radios: [
      {
        value: 1,
        imagesrc: "",
        check: false
      },
      {
        value: 2,
        imagesrc: "",
        check: false
      },
      {
        value: 3,
        imagesrc: "",
        check: false
      },
      {
        value: 4,
        imagesrc: "",
        check: false
      },
      {
        value: 5,
        imagesrc: "",
        check: false
      },
      {
        value: 6,
        imagesrc: "",
        check: false
      },
    ],
    radio: ["A1", "A2", "A3", "A4", "A5", "A6", "A7", "A8", "A9", "A10", "A11", "A12", "B1", "B2", "B3", "B4", "B5", "B6", "B7", "B8", "B9", "B10", "B11", "B12", "C1", "C2", "C3", "C4", "C5", "C6", "C7", "C8", "C9", "C10", "C11", "C12", "D1", "D2", "D3", "D4", "D5", "D6", "D7", "D8", "D9", "D10", "D11", "D12", "F1", "F2", "F3", 'F4', "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12"],
  },

  /**
   * 组件的方法列表
   */
  methods: {

    // getdata: function(){
    //   var pages = getCurrentPages();
    //   var prevpage = pages[pages.length-2];
    //   var info = prevpage.data;
    //   var number = info.number;
    //   console.log(number);
    //   this.setData({
    //     number: number,
    //   })
    //   console.log("getdata函数成功执行！")
    // },

    //计算时间
    countDown: function () {
      var that = this;
      var countDownNum = that.data.countDownNum;
      var dateList = countDownNum.split(":");
      var min = that.data.min;
      var m, s;
      var time = parseInt((parseInt(dateList[0]) * 60) + parseInt(dateList[1]));
      var timer = setInterval(() => {
        if (time > 0) {
          --time;
          min = Math.floor(time / 60 % 60);
          s = Math.floor(time % 60);
          s = s < 10 ? "0" + s : s
          min = min < 10 ? "0" + min : min
          this.setData({
            countDownNum: min + ":" + s,
            min: 40 - min,
          });
        } else {
          console.log('已截止');
          // wx.showToast({
          //   title: '时间已截止',
          // })
          clearInterval(timer);
          that.setData({
            countDownNum: '00:00',
            min: 0
          })
        }
      }, 1000);

    },


    getRandomArray: function (arr) {
      let len = arr.length;
      for (let i = 0; i < len; i++) {
        let randowIndex = parseInt(Math.random() * (len - i));
        let tem = arr[len - i - 1];
        arr[len - i - 1] = arr[randowIndex];
        arr[randowIndex] = tem;
      }
      return arr;
    },

    // 更新题目图片
    getNewsrc: function () {
      var that = this;
      var number = that.data.number;
      var result = that.data.result;
      var arr = result[number - 1];
      var radios = that.data.radios;
      var src = that.data.src;
      //获取题目路径
      src = arr.title;
      //先打乱选项顺序，再获取选项路径
      for (var i = 0; i < 6; i++) {
        radios[i].imagesrc = arr.options[i];
      }
      radios = that.getRandomArray(radios);
      console.log("------------------");
      console.log(radios);
      that.setData({
        radios: radios,
        src: src,
      })
      // for (var i=0; i<arr.length; i++){
      //   count = count + 1;
      //   if (radio[i] == arr[0]){
      //     radio.splice(i,1);
      //   }
      // }
      //根据题目图片找到子图片
      // var letters = ["A","B","C","D","F"];
      // var numbers = ["1","2","3","4","5","6","7","8","9","10","11","12"];
      // var letter;
      // var number1;
      // for (var i=0; i<letters.length; i++){
      //   if (src.indexOf(letters[i]) >= 0){
      //     letter = letters[i];
      //     break;
      //   }
      // }
      // for (var i = 0; i < 6; i++) {
      //   if (src.indexOf(numbers[i]) >= 0) {
      //     number1 = numbers[i];
      //     break;
      //   }
      // }
      // number1 = parseInt(number1 * 10) + 1; 
      // for (var i = 0; i < 6; i++) {
      //   radios[i].imagesrc = "cloud://cbj-dev-qitye.6362-cbj-dev-qitye-1301726804/question/" + letter.toLocaleLowerCase() + number1 + ".jpg";
      //   number1 = parseInt(number1) + 1;
      // }
      console.log("题目图片已更新!")
    },

    buttonEvent: function (e) {
      var that = this;
      var radios = that.data.radios;
      var flags = 0;
      //如果没有选择答案，弹出提示
      for (var i = 0; i < 6; i++) {
        if (!radios[i].check) {
          flags = flags + 1;
        }
      }
      if (flags == 6) {
        wx.showToast({
          title: '请选择答案',
        })
        return;
      }

      var number = that.data.number;
      var title = that.data.random[number - 1];
      var count = that.data.count;
      var counts = that.data.counts;
      var value = that.data.value;
      var result = that.data.result;
      var arr = result[number - 1];
      var answer = parseInt(arr.answer);
      console.log("answer的值为：" + answer);
      for (var i = 0; i < 6; i++) {
        var str = radios[i].imagesrc;
        var len = str.length - 5;
        if (str.lastIndexOf(answer) == len) {
          answer = radios[i].value;
          break;
        }
      }
      if (value == answer) {
        //判断是哪一类题目
        if (title.indexOf("A") >= 0) {
          counts[0] = counts[0] + 1;
          console.log('A类题目答对' + counts[0] + "道!");
        } else if (title.indexOf("B") >= 0) {
          counts[1] = counts[1] + 1;
          console.log('B类题目答对' + counts[1] + "道!");
        } else if (title.indexOf("C") >= 0) {
          counts[2] = counts[2] + 1;
          console.log('C类题目答对' + counts[2] + "道!");
        } else if (title.indexOf("D") >= 0) {
          counts[3] = counts[3] + 1;
          console.log('D类题目答对' + counts[3] + "道!");
        } else if (title.indexOf("F") >= 0) {
          counts[4] = counts[4] + 1;
          console.log('F类题目答对' + counts[4] + "道!");
        }
        //答对题目数加1
        count = count + 1;
        console.log("您答对了" + count + "道题目！");
      } else {
        console.log("您答错了！");
      }
      this.update();
      that.setData({
        count: count,
      })
      var flags = that.data.flag;

      if (flags == 1) {
        // 与页面衔接  触发页面中的方法并传数据
        counts[5] = count;
        var min = that.data.min;
        counts[6] = min;
        that.setData({
          counts: counts,
        })
        that.triggerEvent('showTab', that.data.counts);
        wx.navigateTo({
          url: '../result/index',
        })
      }

    },

    //更新页面内容
    update: function () {
      var that = this;
      var number = that.data.number;
      var flag = that.data.flag;
      var percent;
      var url = that.data.url;
      //清空单选框
      var radios = this.data.radios;//选项集合
      radios.forEach(item => {
        item.check = false;
      })
      //判断是不是最后一题，最后一题跳转
      if (number < 60) {
        number = number + 1;
        this.getPictureData(this.data.random[number - 1]);
        url = '#';
      } else {
        var count = app.globalData.count + 1;
        var nowDate = new Date();
        var date = new Date(nowDate);
        var week = date.getDay();
        date = util.dateLater(date, week);
        console.log("得到count的值：" + count)
        //在这里将count存入数据库
        util.updateTestNum(db, app.globalData.countId, {
          count: count,
          date: date
        })
        flag = 1;
      }
      console.log(number);
      percent = parseInt((number / 60) * 100);
      that.setData({
        number: number,
        percent: percent,
        url: url,
        flag: flag,
        radios: radios,
        value: 0,
      })
      console.log("update函数成功执行!")
    },

    //实时更新单选框的状态
    radioEvent: function (e) {
      console.log(e);
      var index = e.currentTarget.dataset.index;//获取当前点击的下标
      var value = this.data.value;
      console.log(value);
      console.log(index);
      var radios = this.data.radios;//选项集合
      console.log(radios);
      if (radios[index].check) return;//如果点击的当前已选中则返回
      radios.forEach(item => {
        item.check = false;
      })
      radios[index].check = true;//改变当前选中的checked值
      this.setData({
        radios: radios,
        value: value,
      });
    },

    //获得答案
    onClick: function (e) {
      var that = this;
      var value = e.detail.value;
      that.setData({
        value: value,
      })
      console.log("value的值为：" + value);
    },

  // 云服务图片数据
    getPictureData: function(name){
      db.collection('titles').where({
        title: name
      }).get().then(res => {
        console.log("abc",res)
        let data = res.data[0];
        data.title = app.globalData.yunPath + "title/" + data.title + ".jpg";
        data.options = data.options.map(item => app.globalData.yunPath + "questions/" + item + ".jpg");
        console.log(data);
        let arr = this.data.result;
        console.log("123",arr);
        arr.push(data);
        this.setData({
          result: arr
        })
        this.getNewsrc()
      })  
    }
  },

  lifetimes: {
    attached: function () {
      this.countDown();
      //先打乱数组
      var that = this;
      var number = that.data.number;
      if (number == 1) {
        var radio = that.data.radio;
        var random = that.data.random;
        //第一题时，打乱代码并保存
        random = that.getRandomArray(radio);
        that.setData({
          random: random,
        })
      }
      //获取data里面的random[number-1]，返回result[]
      // 云服务图片数据
      this.getPictureData(this.data.random[number - 1]);
    }
  }
})