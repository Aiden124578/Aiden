Page({
  data: {
    a: 0,   //用来判断是不是第一题
    count: 0,
    min: 0,
    counts: [0, 0, 0, 0, 0],
  },

  showTab: function (e) {
    console.log(e);
    console.log("-----------------")
    console.log("e.detail的值为：" + e.detail);
    var number = e.detail;
    var count = number[5];
    var min = number[6];
    var counts = this.data.counts;
    console.log(counts);
    for (var i = 0; i < 5; i++) {
      counts[i] = number[i];
    }
    console.log("-----------------")
    this.setData({
      min: min,
      count: count,
      counts: counts,
    })
    var count = this.data.count;
    console.log("count的值为：" + count);
  },
})