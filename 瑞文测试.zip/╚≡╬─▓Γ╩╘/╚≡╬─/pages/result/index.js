var wxCharts = require('../../style/js/wxcharts-min');
const util = require('../../utils/util')

const app = getApp();
const db = wx.cloud.database()
var radarChart = null;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    min: 0,    //答题时间
    flag: true,
    number: 0,  //答对的题目数
    age: 0,   //年龄的value值
    counts: [0,0,0,0,0],    //ABCDF各类题目分别答对的题目数
    iqs: 0,     //100
    iq: null,   //100-110
    date: null,    //2020-4-19
    note: null,  //智力中等，正常
    ranks: 0, //1级
    color: "#000",
    result: [],    //用来保存从答题记录页面中获取的数据
    // objs: [],    //接收缓存数据对象数组
    obj: {
      count: 0,      //答对题数
      counts: [],    //ABCDF五类题目答对题数
      iqs: 0,        //iq值，比如100
      iq: null,      //iq范围，比如100-110
      date: null,    //答题日期，比如2020-4-19
      note: null,    //智力中等，正常
      rank: 0,       //智力等级
      min: 0,        //答题分钟数
      hasUserInfo: false,
      canIUse: wx.canIUse('button.open-type.getUserInfo'),
    },   //用来封装数据对象，存进数据库
    flag: 0,    //用来判断是否成功获取缓存数据,默认值为0，成功获取缓存数据赋值为1
    rankChart:[
      {
        iq: '1级',
        number: '125以上',
        note: '智力超常，天才',
        iqs: 125,
      },
      {
        iq: '2级',
        number: '119-124',
        note: '智力优秀，非常聪明',
        iqs: 119,
      },
      {
        iq: '3级',
        number: '110-118',
        note: '智力中上，聪明',
        iqs: 110,
      },
      {
        iq: '4级',
        number: '100-110',
        note: '智力中等，正常',
        iqs: 100,
      },
      {
        iq: '5级',
        number: '90-100',
        note: '智力一般，稍差',
        iqs: 90,
      },
      {
        iq: '6级',
        number: '81-89',
        note: '智力中下，反应迟钝',
        iqs: 81,
      },
      {
        iq: '7级',
        number: '76-80',
        note: '智力低下',
        iqs: 76,
      },
      {
        iq: '8级',
        number: '75以下',
        note: '智力存在缺陷',
        iqs: 75,
      }
    ],
    rank:[
      { item: [34, 29, 25, 16, 13, 12, 9] },
      { item: [36, 31, 25, 17, 13, 12, 9] },
      { item: [37, 31, 25, 18, 13, 12, 10] },
      { item: [43, 36, 25, 19, 13, 12, 10] },
      { item: [44, 38, 31, 21, 13, 12, 10] },
      { item: [44, 39, 31, 23, 15, 13, 10] },
      { item: [45, 40, 33, 29, 20, 14, 12] },
      { item: [47, 43, 37, 33, 25, 14, 12] },
      { item: [50, 47, 39, 35, 27, 17, 13] },
      { item: [50, 48, 42, 35, 27, 17, 13] },
      { item: [50, 49, 42, 39, 32, 25, 18] },
      { item: [52, 50, 43, 39, 33, 25, 19] },
      { item: [53, 50, 45, 42, 35, 25, 19] },
      { item: [53, 50, 46, 42, 37, 27, 21] },
      { item: [53, 52, 50, 45, 40, 33, 28] },
      { item: [53, 52, 50, 45, 40, 35, 30] },
      { item: [54, 52, 50, 46, 42, 35, 32] },
      { item: [55, 52, 50, 48, 43, 36, 34] },
      { item: [55, 53, 51, 48, 43, 36, 34] },
      { item: [57, 54, 51, 48, 43, 36, 34] },
      { item: [57, 55, 52, 49, 43, 41, 34] },
      { item: [57, 56, 53, 49, 44, 41, 36] },
      { item: [57, 56, 53, 49, 45, 41, 37] },
      { item: [58, 57, 55, 52, 47, 40, 37] },
      { item: [57, 56, 54, 50, 44, 38, 33] },
      { item: [57, 55, 52, 48, 34, 37, 28] },
      { item: [57, 54, 50, 47, 41, 31, 28] },
      { item: [54, 52, 48, 42, 34, 24, 21] },
      { item: [54, 52, 46, 37, 30, 22, 19] },
      { item: [52, 49, 44, 33, 26, 18, 17] },
    ]
  }, 

  getdata: function(){
      var pages = getCurrentPages();
      console.log(pages);
      var prevpage = pages[pages.length-2];
      console.log(prevpage);
      var info = prevpage.data;
      console.log(info);
      var min = info.min;
      var number = info.count;
      var counts = info.counts;
      var prevpages = pages[pages.length-3];
      var info = prevpages.data;
      console.log("----------------")
      var age = info.value;
      console.log("age的值为："+age);
      this.setData({
        number: number,
        age: age,
        counts: counts,
        min: min,
      })
      console.log("number的值为："+number);
      console.log("getdata函数成功执行！")
    },

  /**
   * 更新数据
   */
  update:function(){
    var age = this.data.age;
    var count = this.data.number;
    var counts = this.data.counts;
    var rank = this.data.rank;
    var ranks = this.data.ranks;
    var rankChart = this.data.rankChart;
    var note = this.data.note;
    var iqs = this.data.iqs;
    var iq = this.data.iq;
    //先判断用户智商的等级
    var arr = rank[age].item;
    console.log(arr);
    console.log(count);
    for (var i=0; i<7; i++){
      arr[i] = parseInt(arr[i]);
      console.log(arr[i]);
      count = parseInt(count);
      if(count >= arr[i]){
        ranks = i+1;
        break;
      }else{
        ranks = 8;
      }
    }
    console.log("----------------------------")
    console.log("ranks的值为："+ranks);
    //分别给智力，智力评价等赋值
    for (var i=1; i<=8; i++){
      ranks = parseInt(ranks);
      if (ranks == i){
        // ranks = rankChart[i-1].iq;
        note = rankChart[i-1].note;
        iqs = rankChart[i-1].iqs;
        iq = rankChart[i-1].number;
      }
    }
    //给时间赋值

    var timestamp = Date.parse(new Date());
    var date = new Date(timestamp);
    //获取年份  
    var Y = date.getFullYear();
    //获取月份  
    var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1);
    //获取当日日期 
    var D = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
    console.log("当前时间：" + Y + '年' + M + '月' + D + '日');
    var dates = Y + "-" + M + "-" + D;
    this.setData({
      date: dates,
      ranks: ranks+"级",
      note: note,
      iqs: iqs,
      iq: iq,
    })
  },

  updates:function(){
    var result = this.data.result;
    // var rank = result.rank;
    // rank = parseInt(rank.substring(0,1));
    var rank = parseInt(result.rank);
    this.setData({
      date: result.date,
      ranks: rank+"级",
      time: result.time,
      number: result.count,
      note: result.note,
      iq: result.iq,
      iqs: result.iqs,
      counts: result.counts,
      min: result.min,
    })
  },

  //打开透明层
  showRule: function () {
    this.setData({
      isRuleTrue: true
    })
  },
  //关闭透明层
  hideRule: function () {
    this.setData({
      isRuleTrue: false
    })
  },

  /*
    -------------------------------------------------------
  */

  moreBtn: function () {
    this.plus();
  },
  //点击弹出
  plus: function () {
    if (!this.data.isPopping) {
      //弹出
      this.popp();
      this.setData({
        isPopping: true
      })
    }
    else {

      //缩回
      this.takeback();
      this.setData({
        isPopping: false
      });
    }
  },
  collect: function () {
    console.log("transpond")
  },

  //弹出动画
  popp: function () {
    //plus顺时针旋转
    let animationPlus = wx.createAnimation({
      duration: 500,
      timingFunction: 'ease'
    })
    let animationcollect = wx.createAnimation({
      duration: 500,
      timingFunction: 'ease'
    })
    animationPlus.rotateZ(180).step();
    animationcollect.translate(-0, -50).rotateZ(0).opacity(1).step();
    this.setData({
      animPlus: animationPlus.export(),
      animCollect: animationcollect.export(),
    })
  },
  //收回动画
  takeback: function () {
    //plus逆时针旋转
    let animationPlus = wx.createAnimation({
      duration: 500,
      timingFunction: 'ease'
    })
    let animationcollect = wx.createAnimation({
      duration: 500,
      timingFunction: 'ease'
    })
    animationPlus.rotateZ(0).step();
    animationcollect.translate(0, 0).rotateZ(0).opacity(0).step();
    this.setData({
      animPlus: animationPlus.export(),
      animCollect: animationcollect.export(),
    })
  },

  /*
    -------------------------------------------------------
  */

  /** * 异步取信息 */
  listenerStorageGet: function () {
    var that = this; 
    wx.getStorage({
      //获取数据的key
      key: 'key',
      success: function (res) {
        console.log(res);
        that.setData({
          objs: res.data,
        })
        console.log("获取缓存数据成功")
      },
      /** * 失败会调用 */
      fail: function (res) {
        console.log(res);
        console.log("获取缓存数据失败")
      }
    })
  },

  /** * 异步存储 */
  listenerStorageSave: function () {
    var storageData = this.data.storageData;
    var obj = this.data.obj;
    obj.count = this.data.number;
    obj.counts = this.data.counts;
    obj.iqs = this.data.iqs;
    obj.iq = this.data.iq;
    obj.date = this.data.date;
    obj.note = this.data.note;
    obj.rank = this.data.ranks;
    console.log(obj);
    var objs = this.data.objs;
    // objs.push(obj);
    var length = objs.length;
    console.log("objs的长度为："+length)
    objs[length] = obj;
    this.setData({
      objs: objs,
    })
    console.log(objs);
    //以键值对的形式存储 传进去的是个对象
    wx.setStorage(
      {
        key: 'key',
        data: objs,
        success: function (res) {
          console.log(res);
          console.log("成功存储缓存数据！");
        }
      })
  },

  buttonEvent:function(){
    wx.reLaunch({
      url: '/pages/index/index',
    })
  },

  
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: async function (options) {
    var flag = 0;    //如果页面是从答题页面跳转的，则将flag赋值为1；如果是从答题记录页面跳转过来的，则将flag赋值为2
    var pages = getCurrentPages();
    var prevpage = pages[pages.length-2];
    console.log(prevpage.route);
    var url = prevpage.route;
    if (url == "pages/beginTest/index"){
      flag = 1;
      this.getdata();
    } else if (url == "pages/record/record"){
      flag = 2;
      var item = options.item;
      var info = prevpage.data;
      console.log(info);
      var result = info.results[item];
      console.log(result);
      this.setData({
        result: result,
      })
      this.updates();
    }
    if (flag == 1){
      this.update();
    }
    //获取缓存数据
    // this.listenerStorageGet();
    // //将数据存储到缓存中
    // this.listenerStorageSave();
    wx.cloud.database().collection("user").get({
        success: res => {
          console.log("请求成功", res)
          this.setData({
            openid: res.data.openid
          })
        },
        fail: err => {
          console.log("请求失败", res)
        }
      })
    // const openid = await app.getOpenid()
    const openid = this.data.openid
    var obj = this.data.obj;
    obj.count = this.data.number;
    obj.counts = this.data.counts;
    obj.iqs = this.data.iqs;
    obj.iq = this.data.iq;
    obj.date = this.data.date;
    obj.note = this.data.note;
    obj.rank = this.data.ranks;
    obj.min = this.data.min;
    obj.openid = openid
    
    this.setData({
      obj: obj,
    })
    // 这里将obj对象存进数据库
    url === "pages/beginTest/index" && util.addRecords(db, obj,1)

    var counts = this.data.counts;
    try {
      // var res = wx.getSystemInfoSync();
      // windowWidth = res.windowWidth;
    } catch (e) {
      console.error('getSystemInfoSync failed!');
    }

    radarChart = new wxCharts({
      canvasId: 'radarCanvas',
      type: 'radar',
      categories: ['知觉辨别：' + counts[0], '类同比较：' + counts[1] , '比较推理：' + counts[2], '系列关系：' + counts[3], '抽象推理：' + counts[4]], // 类别名称
      series: [{
        name: '智力测试类别',
        data: [
          counts[0], // 每个类别对应的值,这个是A类
          counts[1],
          counts[2],
          counts[3],
          counts[4]],
      }],
      width: 330,
      height: 200,
      extra: {
        radar: {
          max: 12  // 每个类别的最大值，每个类别有12个
        }
      }
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },
  touchHandler: function (e) {
    console.log(radarChart.getCurrentDataIndex(e));
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (ops) {
    if (ops.from === 'button') {
      // 来自页面内转发按钮
      console.log(ops.target)
      }
    return {
      title: '瑞文测试',
      desc: '我刚刚测试得到了1级，你也来试试吧',
      path: '/pages/index/index', // 路径，传递参数到指定页面。
      success: function (res) {
        // 转发成功
        console.log("转发成功:" + JSON.stringify(res));
      },
      fail: function (res) {
        // 转发失败
        console.log("转发失败:" + JSON.stringify(res));
      }
    }
  }
})