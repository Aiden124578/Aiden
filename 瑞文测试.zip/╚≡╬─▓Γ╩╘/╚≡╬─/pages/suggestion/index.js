//获取数据库list表
const DB = wx.cloud.database().collection("list")
Page({
  data: {
    // 提交弹窗
    isShow: false,
    //获取数据库中的数据
    dataList: []
  },
  onLoad() {
    //获取用户的信息
    const nickName = this.data.nickName;
    const avatarUrl = this.data.avatarUrl;
    wx.getUserInfo({
      success: res => {
        this.data.nickName = res.userInfo.nickName
        this.data.avatarUrl = res.userInfo.avatarUrl
        this.setData({
          nickName: this.data.nickName,
          avatarUrl: this.data.avatarUrl
        })
      }
    })
    // 检查用户是否微信授权
    wx.getSetting({
      success: res => {
        if (res.authSetting['scope.userInfo']) {
          // 通过云函数获取数据库中的数据
          wx.cloud.callFunction({
            name:"getList",
            success:res=>{
              console.log("请求云函数成功",res)
              this.setData({
                dataList:res.result.data
              })
            },
            fail:err=>{
              console.log("请求云函数失败",err)
            }
          })
          // 获取数据库中的数据
          // DB.get({
          //   success: res => {
          //     console.log("请求成功", res)
          //     this.setData({
          //       dataList: res.data
          //     })
          //     console.log(this.data.dataList)
          //   },
          //   fail: err => {
          //     console.log("请求失败", res)
          //   }
          // })
        } else {
          // 用户未授权，提示用户授权
          wx.showLoading({
            title: '请先登录...',
          })
          setTimeout(() => {
            wx.hideLoading({
              complete: (res) => {
                console.log("已关闭")
                wx.switchTab({
                  url: '../user/index',
                })
              },
            })
          }, 1200);
        }
      }
    })
  },
  // 点击提交
  handleTakeSuggestion() {
    this.setData({
      isShow: true,
    })
  },
  // 取消按钮
  cancelBtn() {
    this.setData({
      isShow: false
    })
  },

  // 失去焦点时获取里面意见内容
  bindTextAreaBlur: function (e) {
    console.log(e.detail.value)
    this.setData({
      content: e.detail.value
    })
  },
  // 提交意见确定
  confirmBtn(e) {
    let that = this
    // 检查用户是否微信授权
    wx.getSetting({
      success: res => {
        if (res.authSetting['scope.userInfo']) {
          let dateTime;
          const timestamp = Date.parse(new Date());
          const date = new Date(timestamp);
          //获取年份  
          const Y =date.getFullYear();
          //获取月份  
          const M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1);
          //获取当日日期 
          const D = date.getDate() < 10 ? '0' + date.getDate() : date.getDate(); 
          //获取时
          const hour = date.getHours()
          //获取分
          const minute = date.getMinutes()
          that.setData({
            dateTime:Y + '年'  + M+ '月' + D+ '日' + ' ' + hour + ':' + minute
          })
          // 添加意见信息到数据库list表
          DB.add({
            data: {
              avatarUrl: that.data.avatarUrl,
              name: that.data.nickName,
              content: that.data.content,
              date: that.data.dateTime
            }, success(res) {
              console.log("添加成功", res)
            }, fail(err) {
              console.log("添加失败", err)
            }
          })
          wx.showLoading({
            title: "提交成功",
            mask: true
          });
          setTimeout(() => {
            wx.hideLoading({
              complete: (res) => {
                console.log("已关闭")
                wx.reLaunch({
                  url: "/pages/suggestion/index"
                });
              },
            })
          }, 666);
        } else {
          // 用户未授权，提示用户授权
          wx.showLoading({
            title: '请先登录...',
          })
          setTimeout(() => {
            wx.hideLoading({
              complete: (res) => {
                console.log("已关闭")
                wx.switchTab({
                  url: '../user/index',
                })
              },
            })
          }, 1200);
        }
      }
    })
  },
})