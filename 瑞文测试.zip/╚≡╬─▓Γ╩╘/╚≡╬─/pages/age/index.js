Page({
  data: {
    number: 0,
    color: "#fff",
    value: 0,

    checkboxArr: [
      {
        listName: '15~79岁',
        item: [
          { itemname: '17~19岁（含19岁11个月30天）', checked: false, value: 29 },
          { itemname: '20~29岁（含29岁11个月30天）', checked: false, value: 28 },
          { itemname: '30~39岁（含39岁11个月30天）', checked: false, value: 27 },
          { itemname: '40~49岁（含49岁11个月30天）', checked: false, value: 26 },
          { itemname: '59~59岁（含59岁11个月30天）', checked: false, value: 25 },
          { itemname: '70~79岁（含79岁11个月30天）', checked: false, value: 24 },
          { itemname: '16岁（16岁3个月1天算起）', checked: false, value: 23 },
          { itemname: '15岁9个月1天~16岁2个月30天', checked: false, value: 22 },
          { itemname: '15岁3个月1天~15岁8个月30天', checked: false, value: 21 },]
      },
      {
        listName: '10~14岁',
        item: [
          { itemname: '14岁9个月1天~15岁2个月30天', checked: false, value: 20 },
          { itemname: '14岁3个月1天~14岁8个月30天', checked: false, value: 19 },
          { itemname: '13岁9个月1天~14岁2个月30天', checked: false, value: 18 },
          { itemname: '13岁3个月1天~13岁8个月30天', checked: false, value: 17 },
          { itemname: '12岁9个月1天~13岁2个月30天', checked: false, value: 16 },
          { itemname: '12岁3个月1天~12岁8个月30天', checked: false, value: 15 },
          { itemname: '11岁9个月1天~12岁2个月30天', checked: false, value: 14 },
          { itemname: '11岁3个月1天~11岁8个月30天', checked: false, value: 13 },
          { itemname: '10岁9个月1天~11岁2个月30天', checked: false, value: 12 },
          { itemname: '10岁3个月1天~10岁8个月30天', checked: false, value: 11 },]
      },
      {
        listName: '5~9岁',
        item: [
          { itemname: '9岁9个月1天~10岁2个月30天', checked: false, value: 10 },
          { itemname: '9岁3个月1天~9岁8个月30天', checked: false, value: 9 },
          { itemname: '8岁9个月1天~9岁2个月30天', checked: false, value: 8 },
          { itemname: '8岁3个月1天~8岁8个月30天', checked: false, value: 7 },
          { itemname: '7岁9个月1天~8岁2个月30天', checked: false, value: 6 },
          { itemname: '7岁3个月1天~7岁8个月30天', checked: false, value: 5 },
          { itemname: '6岁9个月1天~7岁2个月30天', checked: false, value: 4 },
          { itemname: '6岁3个月1天~6岁8个月30天', checked: false, value: 3 },
          { itemname: '5岁9个月1天~6岁2个月30天', checked: false, value: 2 },
          { itemname: '5岁3个月1天~5岁8个月30天', checked: false, value: 1 },]
      }]
  },

  listTap(e) {
    console.log('触发了');
    let Index = e.currentTarget.dataset.parentindex,//获取点击的下标值
      checkboxArr = this.data.checkboxArr;
    console.log("parentindex的值为：" + Index);
    console.log(e);
    checkboxArr[Index].show = !checkboxArr[Index].show || false;
    //变换其打开、关闭的状态
    if (checkboxArr[Index].show) {
      //如果点击后是展开状态，则让其他已经展开的列表变为收起状态
      this.packUp(checkboxArr, Index);
    }
    this.setData({
      checkboxArr: checkboxArr,
      parentindex: Index,
    });
  },

  //让所有的展开项，都变为收起
  packUp(data, index) {
    for (let i = 0, len = data.length; i < len; i++) {
      //其他最外层列表变为关闭状态
      if (index != i) {
        data[i].show = false;
      }
    }
  },

  radio: function (e) {
    console.log(e);
    var index = e.currentTarget.dataset.index;//获取当前点击的下标
    var parentindex = this.data.parentindex;//获取当前点击的父列表下标
    console.log("parentindex的值为：" + parentindex);
    // console.log(index);
    var checkboxArr = this.data.checkboxArr;//选项集合
    if (checkboxArr[parentindex].item[index].checked) return;//如果点击的当前已选中则返回
    checkboxArr.forEach(item => {
      item.checked = false;
    })
    checkboxArr[index].item.checked = true;//改变当前选中的checked值
    this.setData({
      checkboxArr: checkboxArr
    });
  },

  radioChange: function (e) {
    console.log('radio发生change事件，携带value值为：', e.detail.value)
    var value = this.data.value;
    this.setData({
      value: e.detail.value,
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})