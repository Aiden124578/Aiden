Page({
  data: {
    userinfo:{},
    isShow: false
  },
  onShow(){
    const userinfo=wx.getStorageSync("userinfo");
    this.setData({
      userinfo
    })
  },
  onLoad(){
    // 检查用户是否微信授权
    wx.getSetting({
      success: (result) => {
        console.log(result)
      }
    });
  },
  // 意见反馈
  handleSuggestion(){
    wx.showLoading({
      title: "加载中",
      mask: true
    });
    setTimeout(() => {
      wx.hideLoading({
        complete: (res) => {
          console.log("已关闭")
          wx.navigateTo({
            url: '/pages/suggestion/index',
          });
        },
      })
    }, 666);
  },
  // 关于我们
  handleAbout(){
    this.setData({
      isShow: true,
    })
  },
  // 取消按钮
  cancelBtn() {
    this.setData({
      isShow: false
    })
  },
  // 提交意见确定
  confirmBtn() {
    this.setData({
      isShow: false
    })
  },
  // 跳转到历史记录
  recordNav(){
    wx.showLoading({
      title: "加载中",
      mask: true
    });
    setTimeout(() => {
      wx.hideLoading({
        complete: (res) => {
          console.log("已关闭")
          wx.navigateTo({
            url: '/pages/record/index',
          });
        },
      })
    }, 666);
  }
})