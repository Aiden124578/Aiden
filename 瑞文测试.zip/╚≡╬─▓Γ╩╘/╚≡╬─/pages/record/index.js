const util = require('../../utils/util')
const app = getApp()
const db = wx.cloud.database()
Page({
  data: {
    // results: [
    //   {
    //     date: '05 AUG',
    //     rank: '3级',
    //     min: '38mins',
    //     count: 34,
    //     note: '智力中等',
    //     iq: 100,
    //     iqs: '100-110',
    //     counts: [5,5,7,8,9],
    //   },
    //   {
    //     date: '10 MAY',
    //     rank: '6级',
    //     min: '30mins',
    //     count: 43,
    //     note: '智力中上',
    //     iq: 90,
    //     iqs: '90-100',
    //     counts: [6,7,7,4,9]
    //   },
    //   {
    //     date: '23 SEP',
    //     rank: '5级',
    //     min: '23mins',
    //     count: 24,
    //     note: '智力上等',
    //     iq: 110,
    //     iqs: '110-125',
    //     counts: [7,9,10,8,9]
    //   },
    // ],   //假数据
    results: [], //接受返回的结果
    ueserId: 0,    //接收用户id，用来查询答题记录
    flag: 0,     //判断缓存是否获取成功，成功赋值为1
  },

  /** * 异步取信息 */
  listenerStorageGet: function () {
    var that = this;
    wx.getStorage({
      //获取数据的key
      key: 'key',
      success: function (res) {
        console.log(res)
        that.setData({
          storageData: res.data,
          flag: 1,
        })
        console.log("flag赋值成功")
      },
      /** * 失败会调用 */
      fail: function (res) {
        console.log(res);
        console.log("获取缓存数据失败")
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad() {
    // this.listenerStorageGet();
    // var flag = this.data.flag;
    // if (flag == 1){
    //   console.log("获取缓存数据成功")
    // }else if (flag == 0){
    //   console.log("获取缓存数据失败，开始获取数据库数据")
    // }
    // 检查用户是否微信授权
    wx.getSetting({
      success: res => {
        if (res.authSetting['scope.userInfo']) {
          // 获取答题记录
          wx.cloud.database().collection("user").get({
            success: res => {
              console.log("请求成功", res)
              this.setData({
                openid: res.data.openid
              })
            },
            fail: err => {
              console.log("请求失败", res)
            }
          })
          // const openid = await app.getOpenid()
          util.getRecords(db, this.data.openid, data => {
            this.setData({
              results: data
            })
          })
        } else {
          // 用户未授权，提示用户授权
          wx.showLoading({
            title: '请先登录...',
          })
          setTimeout(() => {
            wx.hideLoading({
              complete: (res) => {
                console.log("已关闭")
                wx.switchTab({
                  url: '../user/index',
                })
              },
            })
          }, 1200);
        }
      }
    })

  },
})