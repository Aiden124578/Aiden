Page({
  data: {

  },
  onLoad: function () {

  },
  // 关于测试
  aboutTest() {
    // 显示加载中
    wx.showLoading({
      title: '加载中',
      mask: true
    })
    // 跳转到关于测试页面
    setTimeout(() => {
      wx.hideLoading({
        complete: (res) => {
          console.log("已关闭")
          wx.navigateTo({
            url: '/pages/aboutTest/index'
          });
        },
      })
    }, 666);
  },
  // 开始测试
  beginTest() {
    // 判断用户是否授权，未授权则提示用户授权
    wx.getSetting({
      success: res => {
        if (res.authSetting['scope.userInfo']) {
          wx.showLoading({
            title: '加载中',
            mask: true
          })
          // 跳转页面到开始测试页面
          setTimeout(() => {
            wx.hideLoading({
              complete: (res) => {
                console.log("已关闭")
                wx.navigateTo({
                  url: '/pages/introduction/index'
                });
              },
            })
          }, 666);
        } else {
          wx.showLoading({
            title: '请先登录...',
          })
          setTimeout(() => {
            wx.hideLoading({
              complete: (res) => {
                console.log("已关闭")
                wx.switchTab({
                  url: '../user/index',
                })
              },
            })
          }, 1200);
        }
      }
    })
  }
})
